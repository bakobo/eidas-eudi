---
title: "European Digital Identity Wallet"
subtitle: "ARF Annex 1 - Definitions"
...

# ANNEX 1 - Definitions

## A.1 Introduction

In the Architecture Reference Framework (ARF) many terms are used that need a
precise definition. This Annex contains the definitions of these terms.

In fact, there are three sources for these definitions:

- In the first place, the [European Digital Identity Regulation] defines several
of these terms. For convenience, these definitions are listed in [Section A.2](#a2-definitions-from-the-european-digital-identity-regulation).
- Secondly, the adopted Commission Implementing Regulations [CIR
2024/2977](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R2977),
[CIR 2024/2979](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=OJ:L_202402979),
[CIR 2024/2980](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=OJ:L_202402980),
[CIR 2024/2981](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=OJ:L_202402981),
and [CIR 2024/2982](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=OJ:L_202402982)
also contain a list of definitions. Again for convenience, these definitions are
included in [Section A.3](#a3-definitions-from-the-adopted-commission-implementing-regulations)
- Thirdly, in writing the ARF, additional technical terms and corresponding
definitions are used. These are listed in [Section A.4](#a4-additional-definitions-used-in-the-arf).

## A.2 Definitions from the [European Digital Identity Regulation]

The following terms are defined in the [European Digital Identity Regulation]
and used in the ARF.

| **Term** | **Definition in [European Digital Identity Regulation]** |
|-----------|-----------|
| **Electronic attestation of attributes (EAA)** | An attestation in electronic form that allows attributes to be authenticated. |
| **Attribute** | A characteristic, quality, right or permission of a natural or legal person or of an object. |
| **Authentic Source** | A repository or system, held under the responsibility of a public sector body or private entity, that contains and provides attributes about a natural or legal person or object and that is considered to be a primary source of that information or recognised as authentic in accordance with Union law or national law, including administrative practice. |
| **Authentication** | An electronic process that enables the confirmation of the electronic identification of a natural or legal person or the confirmation of the origin and integrity of data in electronic form. |
| **Conformity Assessment Body (CAB)** | A conformity assessment body as defined in [Article 2, point 13, of Regulation (EC) No 765/2008](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex:32008R0765#d1e497-30-1), which is accredited in accordance with that Regulation as competent to carry out conformity assessment of a qualified trust service provider and the qualified trust services it provides, or as competent to carry out certification of European Digital Identity Wallets or electronic identification means. |
| **Electronic attestation of attributes issued by or on behalf of a public sector body (PuB-EAA)** | An electronic attestation of attributes issued by a public sector body that is responsible for an authentic source or by a public sector body that is designated by the Member State to issue such attestations of attributes on behalf of the public sector bodies responsible for authentic sources in accordance with [Article 45f](https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=CELEX:32024R1183#d1e3902-1-1) and with [Annex VII](https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=CELEX:32024R1183#d1e40-56-1). |
| **Electronic identification scheme** | A system for electronic identification under which electronic identification means are issued to natural or legal persons or natural persons representing other natural persons or legal persons. |
| **(Electronic) signature** | Data in electronic form which is attached to or logically associated with other data in electronic form and which is used by the signatory to sign. |
| **(Electronic) seal** | Data in electronic form which is attached to or logically associated with other data in electronic form to ensure the latter's origin and integrity. |
| **Person Identification Data (PID)** | A set of data that is issued in accordance with Union or national law and that enables the establishment of the identity of a natural or legal person, or of a natural person representing another natural person or a legal person. |
| **Public Sector Body** | A state, regional or local authority, a body governed by public law or an association formed by one or several such authorities or one or several such bodies governed by public law, or a private entity mandated by at least one of those authorities, bodies or associations to provide public services, when acting under such a mandate. |
| **Qualified Electronic Attestation of Attributes (QEAA)** | An electronic attestation of attributes which is issued by a qualified trust service provider and meets the requirements laid down in [Annex V](https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=CELEX:32024R1183#d1e46-54-1). |
| **Qualified Electronic Signature (QES)** | An advanced electronic signature that is created by a qualified electronic signature creation device, and which is based on a qualified certificate for electronic signatures. |
| **Qualified Electronic Signature Creation Device (QSCD)** | Configured software or hardware used to create an electronic signature that meets the requirements laid down in [Annex II](https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=CELEX:32024R1183#d1e38-51-1) of the [European Digital Identity Regulation]. |
| **Qualified Trust Service Provider (QTSP)** | Qualified Trust Service Provider means a trust service provider who provides one or more qualified trust services and is granted the qualified status by the supervisory body. |
| **strong User authentication** | An authentication based on the use of at least two authentication factors from different categories of either knowledge, something only the user knows, possession, something only the user possesses or inherence, something the user is, that are independent, in that the breach of one does not compromise the reliability of the others, and is designed in such a way as to protect the confidentiality of the authentication data |
| **User** | A natural or legal person, or a natural person representing another natural person or a legal person, that uses trust services or electronic identification means provided in accordance with the [European Digital Identity Regulation]. |

**Table 1: Definition of terms used in the ARF originating from the [European Digital Identity Regulation]**

## A.3 Definitions from the adopted Commission Implementing Regulations

The following terms are defined in the adopted Commission Implementing
Regulations and used in the ARF. Note that small differences exist in the way in
which terms are written, for example regarding capitalisation. The table
contains the term as used in the ARF, and uses brackets to indicate shortened or alternative forms used in the ARF.

| **Term** | **Definition** |
|-----------|-----------|
| (Wallet) User | A user who is in control of the Wallet Unit |
| Wallet Unit | A unique configuration of a Wallet Solution that includes Wallet Instances, Wallet Secure Cryptographic Applications and Wallet Secure Cryptographic Devices provided by a Wallet Provider to an individual Wallet User. *Note: In this ARF, a Wallet Unit may additionally include one or more Keystores as specified in Section A.4.* |
| Wallet Solution | A combination of software, hardware, services, settings, and configurations, including Wallet Instances, one or more Wallet Secure Cryptographic Applications and one or more Wallet Secure Cryptographic Devices |
| Provider of person identification data (PID Provider) | A natural or legal person responsible for issuing and revoking the person identification data and ensuring that the person identification data of a user is cryptographically bound to a Wallet Unit |
| Wallet Unit Attestation (WUA) | A data object that describes the components of the Wallet Unit or allows authentication and validation of those components. *Note: The ARF defines two concrete subtypes: the Wallet Instance Attestation (WIA) and the Key Attestation (KA).* |
| Embedded disclosure policy | A set of rules, embedded in an electronic attestation of attributes by its provider, that indicates the conditions that a wallet-relying party has to meet to access the electronic attestation of attributes |
| Registrar (of wallet-relying parties) | The body responsible for establishing and maintaining the list of registered wallet-relying parties established in their territory and who has been designated by a Member State |
| Wallet Instance | The application installed and configured on a Wallet User’s device or environment, which is part of a Wallet Unit, and which the Wallet User uses to interact with the Wallet Unit *Note: Technically speaking, a Wallet Instance can also be a web application.* |
| Wallet Secure Cryptographic Application (WSCA) | An application that manages critical assets by being linked to and using the cryptographic and non-cryptographic functions provided by the Wallet Secure Cryptographic Device |
| Wallet Secure Cryptographic Device (WSCD) | A tamper-resistant device that provides an environment that is linked to and used by the Wallet Secure Cryptographic Application to protect critical assets and provide cryptographic functions for the secure execution of critical operations |
| Wallet Provider | A natural or legal person who provides Wallet Solutions in accordance with Article 5a of Regulation (EU) No 910/2014. |
| critical assets | Assets within or in relation to a Wallet Unit of such extraordinary importance that where their availability, confidentiality or integrity are compromised, this would have a very serious, debilitating effect on the ability to rely on the Wallet Unit |
| Wallet-relying party | A relying party that intends to rely upon Wallet Units for the provision of public or private services by means of digital interaction *Note: The ARF uses this term only in direct quotes from the Commission Implementing Regulations. It mostly uses 'Relying Party', as specified in section A.4.* |
| (Wallet-relying party) access certificate | A certificate for electronic seals or signatures authenticating and validating the wallet-relying party, issued by a provider of wallet-relying party access certificates |
| Provider of wallet-relying party access certificates (Access Certificate Authority, Access CA) | A natural or legal person mandated by a Member State to issue wallet-relying party access certificates to wallet-relying parties registered in that Member State. |
| Provider of (wallet-relying party) registration certificates | A natural or legal person mandated by a Member State to issue wallet-relying party registration certificates to wallet-relying parties registered in that Member State |
| (Wallet-relying party) registration certificate | A data object that indicates the attributes the wallet-relying party has registered to intend to request from Users |

## A.4 Additional definitions used in the ARF

Note: The technical terms and definitions in Table 3 below are intended to be
defined in such a way that they are aligned with the definitions used in the
[European Digital Identity Regulation] and the Commission Implementing
Regulations in Tables 1 and 2, and should be interpreted as such. In case any
definition in Table 3 contradicts a definition from the [European Digital
Identity Regulation] or the Commission Implementing Regulations, the latter take
precedence.

In some cases, a term has its origin in the context of
a specific Topic in [Annex 2](../annex-2/annex-2.01-high-level-requirements.md). In
such a case, the topic number is mentioned in a note. If
the definition relies on an external source, such as a
standard or a formal publication, that source is mentioned.

| **Term** | **Definition** |
|-----------|-----------|
| Administrative validity period (of a PID or attestation) | The date(s) from and/or up to which the attributes in the attestation are valid, which are represented as attribute(s) in the attestation. *Note: Some attestations, for instance diplomas, do not have an administrative validity period.* |
| Attestation | When not further qualified, a collective term for a QEAA, PuB-EAA, or (non-qualified) EAA. |
| Attestation Provider | When not further qualified, a collective term for QEAA Provider, PuB-EAA Provider, or (non-qualified) EAA Provider. |
| Attestation Revocation List | An Attestation revocation mechanism that publishes a list of identifiers of revoked PIDs or attestations. *Note: See [Topic 7](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a235-topic-7-attestation-revocation-and-revocation-checking).* |
| Attestation revocation mechanism | A mechanism provided by a PID Provider or an Attestation Provider (or by an entity acting on its behalf) for communicating the revocation status of PIDs and attestations. *Notes: - Two specific mechanisms are defined in this Annex: the Attestation Revocation List and the Attestation Status List. - See [Topic 7](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a235-topic-7-attestation-revocation-and-revocation-checking).* |
| Attestation Rulebook | A document describing the attestation type, namespace(s), and other features for a specific attestation type. *Note: See [Topic 12](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a239-topic-12-attestation-rulebooks).* |
| Attestation scheme | A machine-readable counterpart of an Attestation Rulebook for a given attestation type, used by software to build requests to Wallet Units and to validate responses at runtime. *Note: See [Section 3.15][315-attestation-scheme-providers-for-qeaas-pub-eaas-and-eaas] and [Section 5.5][55-attestation-rulebooks-and-attestation-schemes] of the main document.* |
| Attestation Scheme Provider | A natural or legal person that defines a specific attestation type and publishes the corresponding Attestation Rulebook and Attestation scheme. *Note: See [Section 3.15][315-attestation-scheme-providers-for-qeaas-pub-eaas-and-eaas] of the main document.* |
| Attestation Status List | An Attestation revocation mechanism that publishes status information (Valid or Invalid) for all relevant PIDs or attestations. *Notes: - Which PIDs or attestations are relevant is determined by the entity publishing the status list. For example, a status list may contain all PIDs or attestations whose validity period is not over yet at the time of publication of the list. - See [Topic 7](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a235-topic-7-attestation-revocation-and-revocation-checking).* |
| Attestation type | An identifier for a type of attestation, unique within the context of the EUDI Wallet ecosystem. *Note: See [Topic 12](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a239-topic-12-attestation-rulebooks).*  |
| Certificate Authority (CA) | An entity which is trusted by one or more parties in the EUDI Wallet ecosystem to create and seal certificates. |
| Certificate Policy (CP) | A named set of rules that indicates the applicability of a certificate to a particular community and/or class of application with common security requirements. |
| Device-bound attestation | An attestation that is cryptographically bound to a private key generated by and kept in a WSCA/WSCD or keystore available to the Wallet Unit, such that a Relying Party can verify that the attestation is being presented from the Wallet Unit to which it was issued. *Note: See [Topic 9](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a236-topic-9-key-attestation-and-wallet-instance-attestation).* |
| Holder | A User presenting attributes from a PID or attestation to a Verifier in a Wallet-to-Wallet interaction. *Notes: - This term is used only in the context of Wallet-to-Wallet interaction. - See also Verifier. - See [Topic 30](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a2319-topic-30-interaction-between-wallet-units).* |
| Holder Wallet Unit | A Wallet Unit operating in Wallet-to-Wallet mode (see [Technical Specification 9](../../technical-specifications/ts9-wallet-to-wallet-interactions.md)) and being used by a Holder to present attributes from a PID or attestation to a Verifier. *Note: See [Topic 30](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a2319-topic-30-interaction-between-wallet-units).* |
| Intermediary | A natural or legal person providing services to one or more Relying Parties ('intermediated Relying Parties') by interacting with Wallet Units on their behalf to request and receive User attributes, in accordance with Art. 5b(10) of the [European Digital Identity Regulation]. *Notes: - According to Art. 5b(10), intermediaries are deemed to be Relying Parties. - See [Topic 52](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a2330-topic-52-relying-party-intermediaries).* |
| Key Attestation (KA) | A type of Wallet Unit Attestation that attests the certification and properties of a WSCA/WSCD or keystore available to the Wallet Unit, and that contains one or more public keys whose corresponding private keys are generated by and stored in that WSCA/WSCD or keystore, as well as a revocation reference for the WSCD or keystore. *Note: See [Topic 9](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a236-topic-9-key-attestation-and-wallet-instance-attestation).* |
| Keystore |  A hardware-backed repository and service that generates, stores, and uses non-critical cryptographic assets within a dedicated hardware security boundary. *Notes: - Examples include a Secure Element, a TPM, TEE, or secure enclave, or a remote HSM. - Critical cryptographic assets are generated, stored, and used in a WSCA/WSCD.* |
| List of Trusted Entities (LoTE) | List of entities that are recognized as trustworthy within a given approval scheme for a specific scope or purpose. *Based on ETSI TS 119 602.* |
| Logical PID or attestation | A PID or attestation as it is understood by the User and seen in their Wallet Unit, independent of any specific data structure, encoding, or proof mechanism. *Notes: - See [Section 5.3][53-logical-versus-technical-pids-and-attestations]. - A single logical PID or attestation can correspond to multiple Technical PIDs or attestations issued to the User's Wallet Unit, simultaneously or over time.* |
| Namespace | A specification of the attribute identifier, syntax and semantics of attributes that can be used in an attestation, having an identifier that is unique within the context of the EUDI Wallet ecosystem. *Note: See [Topic 12](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a239-topic-12-attestation-rulebooks).* |
| National Accreditation Body (NAB) | A body that performs accreditation with authority derived from a Member State under [Regulation (EC) No 765/2008](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex:32008R0765). |
| Non-device-bound attestation | An attestation that is not cryptographically bound to a private key kept in a WSCA/WSCD or keystore available to the Wallet Unit. *Note: See [Topic 9](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a236-topic-9-key-attestation-and-wallet-instance-attestation).* |
| Notification | The act of transferring information to the European Commission. *Note: See [Topic 31](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a2320-topic-31-notification-and-publication-of-pid-provider-wallet-provider-attestation-provider-access-certificate-authority-and-provider-of-registration-certificates).* |
| Pseudonym | Data uniquely representing a User which in itself does not allow to infer the User's attributes or person identification data, without the use of additional information that is kept separately by the issuer of the data uniquely representing the user. *Note: See [Topic 11](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a238-topic-11-pseudonyms).* |
| Public Key Infrastructure (PKI) | Systems, software, and communication protocols that are used by EUDI Wallet ecosystem components to distribute, manage, and control public keys. A PKI publishes public keys and establishes trust within an environment by validating and verifying the public keys mapping to an entity. |
| Qualified Electronic Signature Remote Creation Provider (QESRC Provider) | A natural or a legal person that offers services related to the remote creation, validation, and management of qualified electronic signatures that meet legal requirements and standards in the [European Digital Identity Regulation] to be considered as legally equivalent to handwritten signatures. |
| Relying Party | For the purposes of this ARF, a service provider interacting with a Wallet Unit to request and receive User attributes. *Note: As specified in the [European Digital Identity Regulation], legally speaking, the term 'relying party' includes Attestation Providers (i.e., QEAA Providers, PuB-EAA Providers, and non-qualified EAA Providers), as well as service providers, because all of them rely on European Digital Identity Wallets. Moreover, this term also includes natural or legal persons that rely on a trust service rather than European Digital Identity Wallets. The CIRs use the term 'wallet-relying party' to refer to Attestation Providers and service providers that specifically rely on wallet units (and not on a trust service). However, technically speaking the responsibilities of Attestation Providers are quite different from those of service providers, as is the way they interact with Wallet Units. To avoid confusion, the ARF therefore distinguishes between Relying Parties (i.e., service providers) on the one hand and PID Providers and Attestation Providers on the other hand.* |
| Relying Party Instance | A software and/or hardware module with the capability to interact with a Wallet Unit and to perform Relying Party authentication, that is controlled by a Relying Party. |
| Selective Disclosure | The capability enabling the User to present a subset of the attributes included in a PID or attestation. |
| SUA attestation| An attestation used for strong user authentication in the context of electronic payments, such that, when a Relying Party sends a presentation request for the attestation to a Wallet Unit, it includes transactional data in the request. *Note: See [Topic 20](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a2313-topic-20-strong-user-authentication-for-electronic-payments)* |
| Technical PID or attestation | A PID or attestation as a specific data structure with a specific encoding and proof mechanism, that is present in a Wallet Unit and that corresponds to a Logical PID or attestation of the User of that Wallet Unit. *Notes: - When this ARF talks about 'PIDs' or 'attestations', without qualification, it means technical PIDs or attestations. - See [Section 5.3][53-logical-versus-technical-pids-and-attestations] and [Section 5.4][54-technical-attestation-formats-and-proof-mechanisms].* |
| Technical validity period (of a PID or attestation) | T The dates (and possibly times) from and up to which a technical PID or attestation is valid, which are represented as metadata of the PID or attestation. *Note: All technical PIDs and attestations have a technical validity period, which is typically much shorter than the administrative validity period of the corresponding logical PID or attestation (if existent). The technical validity period is chosen by the PID Provider or Attestation Provider based on a risk analysis, e.g. with regard to User privacy.* |
| Trust Anchor | An authoritative entity represented by a public key and associated data. *Based on RFC 5914.* |
| Trusted List | List that provides information about the status and the status history of the trust services from trust service providers regarding compliance with the applicable requirements and the relevant provisions of the applicable legislation. *Based on ETSI TS 119 612.* |
| Verifier | A User requesting attributes from a PID or attestation from a Holder in a Wallet-to-Wallet interaction. *Notes: - This term is used only in the context of Wallet-to-Wallet interaction. - See also Holder. - See [Topic 30](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a2319-topic-30-interaction-between-wallet-units).* |
| Verifier Wallet Unit | A Wallet Unit operating in Wallet-to-Wallet mode (see [Technical Specification 9](../../technical-specifications/ts9-wallet-to-wallet-interactions.md)) and being used by a Verifier to request attributes from a PID or attestation from a Holder. *Note: See [Topic 30](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a2319-topic-30-interaction-between-wallet-units).* |
| Wallet Instance Attestation (WIA) | A type of Wallet Unit Attestation that attests the integrity and authenticity of a Wallet Instance, and that carries a revocation reference for the Wallet Instance, as well as information about the Wallet Solution, including its name, version, and certification. *Note: See [Topic 9](../annex-2/annex-2.02-high-level-requirements-by-topic.md#a236-topic-9-key-attestation-and-wallet-instance-attestation).* |
| Wallet Provider backend | The part of a Wallet Solution that is operated by the Wallet Provider and that offers Users support with their Wallet Units, performs essential maintenance, and issues Key Attestations and Wallet Instance Attestations to the Wallet Unit. *Note: See [Section 4.3.2][432-components-of-a-wallet-unit] of the main document.* |
| Wallet Unit Service |  The parts of a Wallet Unit running on the Wallet Provider backend (if any). |
